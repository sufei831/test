//CMOS中的时间
struct rtcdate {   
  uint second;    //秒
  uint minute;    //分
  uint hour;      //小时
  uint day;       //天数
  uint month;     //月份
  uint year;      //年份
};
